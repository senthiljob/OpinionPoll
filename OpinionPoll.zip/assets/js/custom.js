$(window).load(function () {

    
});